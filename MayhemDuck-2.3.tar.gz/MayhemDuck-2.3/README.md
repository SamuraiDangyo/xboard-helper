# MayhemDuck

- Linux UCI DuckChess engine
- Written in C++20 language
- Optimized for speed and simplicity
- UCI protocol supported ( Use UCI2WB for uci -> xboard )
- Lots of internal tools. See `help` for more info
- Works well w/o GUI. See `play`

## Commands

See: `help`

help          : This help
uci           : Outputs the engine info
isready       : Synchronization of the engine. Responded w/ 'readyok'
ucinewgame    : Sent before the game
stop          : Stop the search and report a bestmove
quit          : Exits the engine ASAP
test          : Unittest Symmetry
flip ...      : Flip position
p ...         : Print ASCII art board
play ...      : Play game
u64 ...       : Convert (num)ber to u64 art
think ...     : Think a move infinitely ( 'stop' to quit )
tune ...      : Tune the engine
list ...      : Print movelist
setoption ... : Sets a given option ( See 'uci' )
go ...        : Search the current position with the provided settings
position ...  : Sets the board position via an optional FEN and optional move list
perft ...     : Calculate perft split numbers
bench ...     : Bench signature and speed of the program

## Options

- Debug (false)      : Writes debug information to "mayhemduck-debug.txt" file.
- OwnBook (true)     : Small internal opening book. To avoid repetition.
- MoveOverhead (100) : Time buffer to avoid time losses
- Level (100)        : Playing level 0 -> 100
- Hash (256)         : Hash in MB
- Duck960 (false)    : Chess960 positions for duck
