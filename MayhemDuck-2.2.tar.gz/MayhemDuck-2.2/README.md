# MayhemDuck

- Linux UCI DuckChess engine
- Written in C++20 language
- Optimized for speed and simplicity
- UCI protocol supported ( Use UCI2WB for uci -> xboard )
- Lots of internal tools. See `help` for more info
- Works well w/o GUI. See `play`

## Options

- Debug (false)      : Writes debug information to "mayhemduck-debug.txt" file.
- OwnBook (true)     : Small internal opening book. To avoid repetition.
- MoveOverhead (100) : Avoid time losses
- Level (100)        : Playing level 0 -> 100
- Hash (256)         : Hash in MB
- Duck960 (false)    : Chess960 positions for duck
