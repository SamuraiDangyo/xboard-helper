# MayhemDuck

- Linux UCI DuckChess engine
- Written in C++20 language
- Optimized for speed and simplicity
- UCI protocol supported ( Use UCI2WB for uci -> xboard )
- Lots of internal tools. See `help` for more info
- Works well w/o GUI. See `play`
